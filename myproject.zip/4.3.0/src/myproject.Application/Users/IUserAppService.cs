using System.Threading.Tasks;
using Abp.Application.Services;
using Abp.Application.Services.Dto;
using myproject.Roles.Dto;
using myproject.Users.Dto;

namespace myproject.Users
{
    public interface IUserAppService : IAsyncCrudAppService<UserDto, long, PagedResultRequestDto, CreateUserDto, UpdateUserDto>
    {
        Task<ListResultDto<RoleDto>> GetRoles();
    }
}