﻿namespace myproject
{
    public class myprojectConsts
    {
        public const string LocalizationSourceName = "myproject";

        public const bool MultiTenancyEnabled = true;
    }
}